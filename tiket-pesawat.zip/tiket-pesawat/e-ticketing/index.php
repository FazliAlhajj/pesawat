<?php require 'layouts/navbar.php'; 

$page = "index";

?>


<?php 
$jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");

if (isset($_GET['query']) && !empty($_GET['query'])) {
    $search_query = $_GET['query'];
    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
                                INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
                                INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai 
                                WHERE nama_maskapai LIKE '%$search_query%' OR rute_asal LIKE '%$search_query%' OR rute_tujuan LIKE '%$search_query%' 
                                ORDER BY tanggal_pergi, waktu_berangkat");
}

?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Workbench&display=swap" rel="stylesheet">
<title>Halaman Pelanggan </title>
<form action="index.php" method="get" style="margin-left: 920px;">
      <input type="text" id="search_query" name="query" required  placeholder="Mau Jalan-jalan Kemana nih?">
      <button type="submit" style="background-color: blueviolet;">Search</button>
</form><br>


<div class="content" style="margin-left:410px; margin-bottom: 150px;">
    <img src="pesawat.jpg" alt="ini foto" width="1100px;">
    <marquee style="color: red; font-size: 40px;   font-family: Workbench, sans-serif; ">  Kamu bingung ingin membeli tiket pesawat dengan harga yang murah? Pesan disini solusinya | E-ticketing Bandara Soekarno Hatta - Are you confused about buying plane tickets at a cheap price? Order here the solution | Soekarno Hatta Airport E-ticketing</marquee>
</div>

<h1 class="justify-content-center">Jadwal Penerbangan E-Ticketing Airplane</h1>
<div class="list-tiket-pswt">
    <div class="wrapper-tiket-pswt" style="background-color:#FFB996; border-radius:20px;">
        <?php foreach($jadwalPenerbangan as $data) : ?>
            <div class="card-tiket-pswt" style="border-radius:40px;">
            <a href="detail.php?id=<?= $data["id_jadwal"] ?>">
                <div class="image"><img src="assets/images/<?= $data["logo_maskapai"]; ?>" width="200px;"></div><br>
                <div class="nama-maskapai"><?= $data["nama_maskapai"]; ?></div>
                <div class="rute-penerabangan"><?= $data["rute_asal"] ?> - <?= $data["rute_tujuan"]; ?></div>
                <div class="jadwal-penerbangan"><?= $data["waktu_berangkat"] ?> - <?= $data["waktu_tiba"]; ?></div>
                <div class="text-harga">Rp<?= number_format($data["harga"]); ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>