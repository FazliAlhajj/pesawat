<?php require 'layouts/navbar.php'; ?>
<?php 

$id_user = $_SESSION["id_user"];
$orderTiket = mysqli_query($conn, "SELECT order_tiket.id_order, order_tiket.struk, order_tiket.status, order_detail.id_order, order_detail.id_user, user.id_user FROM order_tiket INNER JOIN order_detail ON order_tiket.id_order = order_detail.id_order INNER JOIN user On order_detail.id_user = user.id_user WHERE user.id_user = '$id_user' GROUP BY order_tiket.id_order");

?>

<div class="list-tiket-pesawat">
    <h1>History - E Ticketing</h1>
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th style="background-color: #C499F3;">No Order</th>
            <th style="background-color: #C499F3;">Struk</th>
            <th style="background-color: #C499F3;">Status</th>

        </tr>
        <?php foreach($orderTiket as $data) : ?>
        <tr>
            <td style="background-color: #EEF0E5;"><?= $data["id_order"]; ?></td>
            <td style="background-color: #EEF0E5;"><?= $data["struk"]; ?></td>
            <td style="background-color: #EEF0E5;"><?= $data["status"]; ?></td>
           
        </tr>
        <?php endforeach; ?>
    </table>
</div>