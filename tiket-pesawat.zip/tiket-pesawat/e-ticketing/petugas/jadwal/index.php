<?php

session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$jadwal = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");


?>

<?php require '../../layouts/sidebar_petugas.php'; ?>

<div class="main">
<h1 style="margin-left: 300px;">Halaman Data Jadwal Penerbangan</h1>
<a href="tambah.php">Tambah</a>
<table border="1" cellpadding="10" cellspacing="0" style="margin-left:215px; ">
    <tr>
        <th style="background-color:#E2F4C5;">No</th>
        <th style="background-color:#E2F4C5;">Nama Maskapai</th>
        <th style="background-color:#E2F4C5;">Rute Asal</th>
        <th style="background-color:#E2F4C5;">Rute Tujuan</th>
        <th style="background-color:#E2F4C5;">Tanggal Pergi</th>
        <th style="background-color:#E2F4C5;">Waktu Berangkat</th>
        <th style="background-color:#E2F4C5;">Waktu Tiba</th>
        <th style="background-color:#E2F4C5;">Harga</th>
        <th style="background-color:#E2F4C5;">Kapasitas Kursi</th>
        <th style="background-color:#E2F4C5;">Aksi</th>
        
    </tr>

    <?php $no = 1; ?>
    <?php foreach($jadwal as $data) : ?>
    <tr>
        <td style="background-color:#76ABAE;"><?= $no; ?></td>
        <td style="background-color:#76ABAE;"><?= $data["nama_maskapai"]; ?></td>
        <td style="background-color:#76ABAE;"><?= $data["rute_asal"]; ?></td>
        <td style="background-color:#76ABAE;"><?= $data["rute_tujuan"]; ?></td>
        <td style="background-color:#76ABAE;"><?= $data["tanggal_pergi"]; ?></td>
        <td style="background-color:#76ABAE;"><?= $data["waktu_berangkat"]; ?></td>
        <td style="background-color:#76ABAE;"><?= $data["waktu_tiba"]; ?></td>
        <td style="background-color:#76ABAE;">Rp <?= number_format($data["harga"]); ?></td>
        <td style="background-color:#76ABAE;"><?= $data["kapasitas_kursi"]; ?></td>
        <td style="background-color:#76ABAE;">
            <button style="background-color:#D37676;"><a href="edit.php?id=<?= $data["id_jadwal"]; ?>">Edit</a></button>
            <button style="background-color:#FF407D;"><a href="hapus.php?id=<?= $data["id_jadwal"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Hapus</a></button>
        </td>
    </tr>
    <?php $no++; ?>
    <?php endforeach; ?>
</table>

</div>