<?php
$page = 'Pengguna';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$pengguna = query("SELECT * FROM user WHERE roles = 'Maskapai' || roles ='Penumpang'");

?>

<?php require '../../layouts/sidebar_petugas.php'; ?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">

<div class="tabel-admin" style="margin-left: 300px;">
    <h1>Data pengguna | E - Ticketing Airplane</h1>
    <a href="tambah.php">Tambah</a>
    <table border="1" cellpadding="10" cellspacing="0" style="margin-top: 25px;">
        <tr>
            <th style="background-color:#76ABAE;">No</th>
            <th style="background-color:#76ABAE;">Username</th>
            <th style="background-color:#76ABAE;">Nama lengkap</th>
            <th style="background-color:#76ABAE;">Roles</th>
            <th style="background-color:#76ABAE;">Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($pengguna as $data) : ?>
            <tr>
                <td style="background-color:#76ABAE;"><?= $no; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["username"]; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["nama_lengkap"]; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["roles"]; ?></td>
                <td style="background-color:#76ABAE;">
                    <button style="background-color:#D37676;"><a href="edit.php?id=<?= $data["id_user"]; ?>">Edit</a></button>
                    <button style="background-color:#FF407D;"><a href="hapus.php?id=<?= $data["id_user"]; ?>" onClick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a></button>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>