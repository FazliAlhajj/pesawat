<?php

session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$rute = query("SELECT * FROM rute INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai");

?>

<?php require '../../layouts/sidebar_petugas.php'; ?>

<div class="rute">
    <h1 style="margin-left:300px;">Data Rute | E - Ticketing</h1>
    <a href="tambah.php">Tambah</a><br><br> 
    <table border="1" cellpadding="10" cellspacing="0" style="margin-left: 300px;">
        <tr>
            <th style="background-color:#76ABAE;">No</th>
            <th style="background-color:#76ABAE;">Nama Maskapai</th>
            <th style="background-color:#76ABAE;">Rute Asal</th>
            <th style="background-color:#76ABAE;">Rute Tujuan</th>
            <th style="background-color:#76ABAE;">Tanggal Pergi</th>
            <th style="background-color:#76ABAE;">Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($rute as $data) : ?>
            <tr>
                <td style="background-color:#76ABAE;"><?= $no; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["nama_maskapai"]; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["rute_asal"]; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["rute_tujuan"]; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["tanggal_pergi"]; ?></td>
                <td style="background-color:#76ABAE;">
                    <button style="background-color:#D37676;"><a href="edit.php?id=<?= $data["id_rute"]; ?>">Edit</a></button>
                    <button style="background-color:#FF407D;"><a href="hapus.php?id=<?= $data["id_rute"]; ?>" onClick="return confirm('Apakah ANda yakin ingin menghapus data ini?')">Hapus</a></button>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>