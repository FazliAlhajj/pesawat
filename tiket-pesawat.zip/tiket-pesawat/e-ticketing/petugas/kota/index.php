<?php

session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$kota = query("SELECT * FROM kota");

?>

<?php require '../../layouts/sidebar_petugas.php'; ?>


<div class="main">
    <h1 style="margin-left: 300px;">Data Kota | E - Ticketing</h1>
    <a href="tambah.php">Tambah</a><br><br> 
    <table border="1" cellpadding="10" cellspacing="0" style="margin-left: 350px;">
        <tr>
            <th style="background-color:#76ABAE;">No</th>
            <th style="background-color:#76ABAE;">Nama kota</th>
            <th style="background-color:#76ABAE;">Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($kota as $data) : ?>
            <tr>
                <td style="background-color:#76ABAE;"><?= $no; ?></td>
                <td style="background-color:#76ABAE;"><?= $data["nama_kota"]; ?></td>
                <td style="background-color:#76ABAE;">
                    <button style="background-color:#D37676;"><a href="edit.php?id=<?= $data["id_kota"]; ?>">Edit</a></button>
                    <button style="background-color:#FF407D;"><a href="hapus.php?id=<?= $data["id_kota"]; ?>" onClick="return confirm('Apakah ANda yakin ingin menghapus data ini?')">Hapus</a></button>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>