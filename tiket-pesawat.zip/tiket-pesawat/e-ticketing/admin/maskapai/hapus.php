<?php

require 'function.php';

$id = $_GET["id"];


if(hapus($id) > 0){
    echo"
        <script type=text/javascript>
            alert('YAy! Data Maskapai Berhasil Di Hapus');
            window.location = 'index.php';
        </script>
    ";
}else{
    echo"
        <script typw=text/javascript>
            alert('Yha... Data Maskapai Gagal Di Hapus');
            window.location = 'index.php';
        </script>
    ";
}

?>