<?php

$page = 'Maskapai';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$maskapai = query("SELECT * FROM maskapai");

?>

<?php require '../../layouts/sidebar_admin.php'; ?>


<link rel="stylesheet" href="../../assets/style/sidebar.css">
<div class="tabel-maskapai">
    <h1 style="margin-left:250px;">Data maskapai | E - Ticketing</h1>
    <a href="tambah.php"  style="margin-left:250px;">Tambah</a><br>
    <table border="1" cellpadding="10" cellspacing="0" style="margin-left:250px;">
        <tr>
            <th style="background-color:#E5E483;">No</th>
            <th style="background-color:#E5E483;">Model Pesawat</th>
            <th style="background-color:#E5E483;">Jenis Pesawat</th>
            <th style="background-color:#E5E483;">Kapasitas</th>
            <th style="background-color:#E5E483;">Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($maskapai as $data) : ?>
            <tr>
                <td style="background-color:#F7DED0;"><?= $no; ?></td>
                <td style="background-color:#F7DED0;"><img src="../../assets/images/<?= $data["logo_maskapai"]; ?>" width="100"></td>
                <td style="background-color:#F7DED0;"><?= $data["nama_maskapai"]; ?></td>
                <td style="background-color:#F7DED0;"><?= $data["kapasitas"]; ?></td>
                <td style="background-color:#F7DED0;">
                    <button style="background-color:#8CB9BD; border-radius:5px;"><a href="edit.php?id=<?= $data["id_maskapai"]; ?>">Edit</a></button>
                    <button style="background-color:#FF004D; border-radius:5px;"><a href="hapus.php?id=<?= $data["id_maskapai"]; ?>" onClick="return confirm('Apakah ANda yakin ingin menghapus data ini?')">Hapus</a></button>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>
