<?php

$page = 'Maskapai';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

if(isset($_POST["tambah"])){
    if(tambah($_POST) > 0){
        echo "
        <script type='text/javascript'>
            alert('YAy! data maskapai berhasil ditambahkan!');
            window.location = 'index.php'
        </script>
    ";
    }else{
        echo "
        <script type='text/javascript'>
            alert('Yah! data maskapai gagal ditambahkan!');
            window.location = 'index.php'
        </script>
    ";
    }
}

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<div class="main">
    <h1>Tambah Data maskapai | E - Ticketing</h1>
    <form action="" method="post" enctype="multipart/form-data">
        
        <label for="logo_maskapai">logo maskapai</label>
        <input type="file" name="logo_maskapai" id="logo_maskapai" class="form-control"><br><br>

        <label for="nama_maskapai">nama maskapai</label><br>
        <input type="text" name="nama_maskapai" id="nama_maskapai" class="form-control"><br><br>

        <label for="kapasitas">kapasitas</label><br>
        <input type="text" name="kapasitas" id="kapasitas" class="form-control"><br><br>

        <button type="submit" name="tambah">tambah</button>
    </form>
</div>