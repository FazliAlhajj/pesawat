<?php

$page = 'Kota';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$kota = query("SELECT * FROM kota");

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">
<div class="tabel-kota">
    <h1>Data kota | E - Ticketing</h1>
    <a href="tambah.php" style="color: white;">Tambah</a><br><br> 
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>No</th>
            <th>Nama kota</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($kota as $data) : ?>
            <tr>
                <td><?= $no; ?></td>
                <td><?= $data["nama_kota"]; ?></td>
                <td>
                    <a href="edit.php?id=<?= $data["id_kota"]; ?>" style="color: green; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif">Edit</a>
                    <a href="hapus.php?id=<?= $data["id_kota"]; ?>" onClick="return confirm('Apakah ANda yakin ingin menghapus data ini?')" style="color:red; font-family:Arial, Helvetica, sans-serif;">Hapus</a>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>