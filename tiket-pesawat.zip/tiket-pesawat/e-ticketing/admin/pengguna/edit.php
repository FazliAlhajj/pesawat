<?php

$page = 'Pengguna';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$id = $_GET["id"];
$pengguna = query("SELECT * FROM user WHERE id_user = '$id'")[0];

if(isset($_POST["edit"])){
    if(edit($_POST) > 0){                                                      
        echo "
        <script type='text/javascript'>
            alert('YAy! data pengguna berhasil di edit!');
            window.location = 'index.php'
        </script>
    ";
    }else{
        echo "
        <script type='text/javascript'>
            alert('yah! data pengguna gagal di edit!');
            window.location = 'index.php'
        </script>
    ";
    }
}

?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">
<?php require '../../layouts/sidebar_admin.php'; ?>
<div class="edit">
    <h1>edit Data pengguna | E - Ticketing</h1>
    <form action="" method="post">
        <input type="hidden" name="id_user" value="<?= $pengguna["id_user"]; ?>">

        <label for="username">Username</label>
        <input type="text" name="username" id="username" class="form-control" value="<?= $pengguna["username"]; ?>"><br><br>

        <label for="nama_lengkap">nama lengkap</label>
        <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" value="<?= $pengguna["username"]; ?>"><br><br>

        <label for="password">password</label>
        <input type="text" name="password" id="password" class="form-control" value="<?= $pengguna["username"]; ?>"><br><br>

        <label for="roles">Roles</label>
        <select name="roles" id="roles">
            <option value="<?= $pengguna["roles"]; ?>"><?= $pengguna["roles"]; ?></option>
            <option value="Maskapai">Maskapai</option>
            <option value="Penumpang">Penumpang</option>
        </select>

        <button type="submit" name="edit">Edit</button>
    </form>
</div>