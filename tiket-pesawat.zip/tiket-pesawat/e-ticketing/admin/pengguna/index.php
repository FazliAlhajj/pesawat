<?php
$page = 'Pengguna';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}

$pengguna = query("SELECT * FROM user WHERE roles = 'Maskapai' || roles ='Penumpang'");

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">

<div class="tabel-admin" style="margin-right:50px;">
    <h1 style="margin-left:50px;">Data pengguna | E - Ticketing</h1>
    <a href="tambah.php" style="margin-left:50px; background-color:#5356FF; border-radius: 4px; color: white; margin-bottom: 9px;">Tambah</a>
 
    <table border="2" cellpadding="12" cellspacing="5" style="margin-left:50px;">
        <tr>
            <th style="background-color:#4CCD99;">No</th>
            <th style="background-color:#4CCD99;">Username</th>
            <th style="background-color:#4CCD99;">Nama lengkap</th>
            <th style="background-color:#4CCD99;">Roles</th>
            <th style="background-color:#4CCD99;">Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($pengguna as $data) : ?>
            <tr>
                <td style="background-color: #F4EDCC"><?= $no; ?></td>
                <td style="background-color: #F4EDCC"><?= $data["username"]; ?></td>
                <td style="background-color: #F4EDCC"><?= $data["nama_lengkap"]; ?></td>
                <td style="background-color: #F4EDCC"><?= $data["roles"]; ?></td>
                <td style="background-color: #F4EDCC">
                    <button style="background-color: #EFBC9B; border-radius: 5px; margin-left:8px;"><a href="edit.php?id=<?= $data["id_user"]; ?>">Edit</a></button>
                    <button style="background-color: #FF204E;  border-radius: 5px; margin-right:10px;"><a href="hapus.php?id=<?= $data["id_user"]; ?>" onClick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a></button>
                </td>
            </tr>
        <?php $no++; ?>
        <?php endforeach; ?>    
    </table>
</div>