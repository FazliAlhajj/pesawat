<?php

$page = 'Pengguna';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
        <script type='text/javascript'>
            alert('Silahkan login terlebih dahulu ya!');
            window.location = '../auth/login/'
        </script>
    ";
}


if(isset($_POST["tambah"])){
    if(tambah($_POST) > 0){
        echo "<script type='text/javascript'>
                setTimeout(function () { 
                    swal({
                        title: 'Yay! data berhasil ditambahkan!',
                        type: 'success',
                        timer: 3200,
                        showConfirmButton: true
                    });   
                },10);  
                window.setTimeout(function(){ 
                window.location.replace('index.php');
                } ,1000); 
              </script>";
    }else{
        echo "
        <script type='text/javascript'>
            alert('Yah! data pengguna gagal ditambahkan!');
            window.location = 'index.php'
        </script>
    ";
    }
}

?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">
<div class="main">
    <h1>Tambah Data pengguna | E - Ticketing</h1>
    <form action="" method="post">
        <label for="username">Username</label><br>
        <input type="text" name="username" id="username" class="form-control"><br><br>

        <label for="nama_lengkap">nama lengkap</label><br>
        <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control"><br><br>

        <label for="password">password</label><br>
        <input type="password" name="password" id="password" class="form-control"><br><br>

        <label for="roles">Roles</label>
        <select name="roles" id="roles">
            <option value="Maskapai">Maskapai</option>
            <option value="Penumpang">Penumpang</option>
        </select>

        <button type="submit" name="tambah">tambah</button>
    </form>
</div>