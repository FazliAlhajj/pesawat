<?php

$page = "Rute";
session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$rute = query("SELECT * FROM rute INNER JOIN maskapai ON maskapai.id_maskapai = rute.id_maskapai ORDER BY rute_asal");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>rute</title>

    <link rel="stylesheet" href="../../assets/style/main.css">
</head>
<body>
    
<div class="content">
   
    <h1 style="margin-left:150px;">Halaman Data Rute</h1>
    
    <a href="tambah.php" style="margin-left:150px;">Tambah</a>
    <table border="1" cellpadding="10" cellspacing="0" style="margin-left:150px;">
        <tr>
            <th style="background-color:#E5E483;">No</th>
            <th style="background-color:#E5E483;">Nama Maskapai</th>
            <th style="background-color:#E5E483;">Rute Asal</th>
            <th style="background-color:#E5E483;">Rute Tujuan</th>
            <th style="background-color:#E5E483;">Tanggal Pergi</th>
            <th style="background-color:#E5E483;">Aksi</th>
        </tr>
    
        <?php $no = 1; ?>
        <?php foreach($rute as $data) : ?>
        <tr>
            <td><?= $no; ?></td>
            <td><?= $data["nama_maskapai"]; ?></td>
            <td><?= $data["rute_asal"]; ?></td>
            <td><?= $data["rute_tujuan"]; ?></td>
            <td><?= $data["tanggal_pergi"]; ?></td>
            <td>
                <button style="background-color:#8CB9BD; border-radius:5px;"><a href="edit.php?id=<?= $data["id_rute"]; ?>">Edit</a></button>
                <button style="background-color:#FF004D; border-radius:5px;"><a href="hapus.php?id=<?= $data["id_rute"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Hapus</a></button>
            </td>
        </tr>
        <?php $no++; ?>
        <?php endforeach; ?>
    </table>
</div>

</body>
</html>
