<?php

$page = 'Jadwal';
session_start();
require 'function.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$jadwal = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<link rel="stylesheet" href="../../assets/style/sidebar.css">
<div class="tabel-jadwal" style="margin-left:  50px; margin-right: 50px;">
    <h1>Halaman Data Jadwal Penerbangan</h1>
    <a href="tambah.php">Tambah</a>
    <table border="1" cellpadding="2" cellspacing="2">
        <tr>
            <th style="background-color:#E5E483;">No</th>
            <th style="background-color:#E5E483;">Nama Maskapai</th>
            <th style="background-color:#E5E483;">Rute Asal</th>
            <th style="background-color:#E5E483;">Rute Tujuan</th>
            <th style="background-color:#E5E483;">Tanggal Pergi</th>
            <th style="background-color:#E5E483;">Waktu Berangkat</th>
            <th style="background-color:#E5E483;">Waktu Tiba</th>
            <th style="background-color:#E5E483;">Harga</th>
            <th style="background-color:#E5E483;">Kapasitas Kursi</th>
            <th style="background-color:#E5E483;">Aksi</th>
        </tr>

        <?php $no = 1; ?>
        <?php foreach($jadwal as $data) : ?>
        <tr>
            <td style="background-color:#F7DED0;"><?= $no; ?></td>
            <td style="background-color:#F7DED0;"><?= $data["nama_maskapai"]; ?></td>
            <td style="background-color:#F7DED0;"><?= $data["rute_asal"]; ?></td>
            <td style="background-color:#F7DED0;"><?= $data["rute_tujuan"]; ?></td>
            <td style="background-color:#F7DED0;"><?= $data["tanggal_pergi"]; ?></td>
            <td style="background-color:#F7DED0;"><?= $data["waktu_berangkat"]; ?></td>
            <td style="background-color:#F7DED0;"><?= $data["waktu_tiba"]; ?></td>
            <td style="background-color:#F7DED0;">Rp <?= number_format($data["harga"]); ?></td>
            <td style="background-color:#F7DED0;"><?= $data["kapasitas_kursi"]; ?></td>
            <td style="background-color:#F7DED0;">
                <button style="background-color:#8CB9BD; border-radius:5px;"><a href="edit.php?id=<?= $data["id_jadwal"]; ?>">Edit</a></button>
                <button style="background-color:#FF004D; border-radius:5px;"><a href="hapus.php?id=<?= $data["id_jadwal"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Hapus</a></button>
            </td>
        </tr>
        <?php $no++; ?>
        <?php endforeach; ?>
    </table>
</div>