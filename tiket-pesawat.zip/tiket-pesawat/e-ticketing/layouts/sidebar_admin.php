<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar Admin</title>
    <link rel="stylesheet" href="/tiket-pesawat/e-ticketing/assets/style/sidebar.css">
    <link rel="stylesheet" href="/tiket-pesawat/e-ticketing/sweet-alert/css/bootstrap.min.css">
    <link rel="stylesheet" href="/tiket-pesawat/e-ticketing/sweet-alert/css/sweetalert.css">
</head>
<style>
  body {
    display: flex;
    height: 100vh;
    margin: 0;
    background-color: #f5f5f5;
}

.sidebar-admin {
    width: 200px;
    background-color: #7ED7C1;
    color: #fff;
    padding: 30px;
    border-radius: 5px;
}

.sidebar-admin a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

a.active{
    background: red;
    color: white;
}

</style>
<body>
    <div class="sidebar-admin">
        <h2 class="w3-bar-block">Tabel Admin</h2>
        <a href="../index.php" class="<?php if($page == "Dashboard") echo "active" ?>"><i class=""></i>Dashboard</a>&nbsp;&nbsp;
        <a href="/tiket-pesawat/e-ticketing/admin/pengguna" class="<?php if($page == "Pengguna") echo "active" ?>"><i class="fa-solid fa-user"></i> Data User</a>
        <a href="/tiket-pesawat/e-ticketing/admin/rute" class="<?php if($page == "Rute") echo "active" ?>"><i class="fa-solid fa-user"></i> Data Rute</a>
        <a href="/tiket-pesawat/e-ticketing/admin/maskapai" class="<?php if($page == "Maskapai") echo "active" ?>"><i class="fa-solid fa-user"></i> Data Maskapai</a>
        <a href="/tiket-pesawat/e-ticketing/admin/jadwal" class="<?php if($page == "Jadwal") echo "active" ?>"><i class="fa-solid fa-calendar-days"></i> Data Jadwal Penerbangan </a>
        <a href="/tiket-pesawat/e-ticketing/admin/order" class="<?php if($page == "Pemesanan") echo "active" ?>"><i class="fa-solid fa-ticket"></i> Konfirmasi Pembayaran</a>
        <a href="/tiket-pesawat/e-ticketing/admin/riwayat" class="<?php if($page == "Riwayat") echo "active" ?>"><i class="fa-solid fa-ticket"></i> Riwayat Transaksi</a>
        <a href="../logout.php" class="w3-bar-item w-3-button" onClick="return confirm('Apakah anda yakin ingin logout?');" style="text-decoration: none; border-radius: 7px; background-color:#7071E8;"><i class="fa-solid fa-arrow-right-from-bracket">Logout</i></a>
    </div>
    <script src="/tiket-pesawat/e-ticketing/sweet-alert/js/jsquery-2.1.4.min.js"></script>
    <script src="/tiket-pesawat/e-ticketing/sweet-alert/js/swe  etalert.min.js"></script>
</body>
</html>
